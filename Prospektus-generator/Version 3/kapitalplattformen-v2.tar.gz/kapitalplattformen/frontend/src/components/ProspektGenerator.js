import React from 'react';

function ProspektGenerator({ user, project, onBack }) {
  return (
    <div className="module-container">
      <div className="module-header">
        <button className="back-button" onClick={onBack}>← Tillbaka</button>
        <h1>📄 Prospekt/IM Generator</h1>
      </div>

      <div className="module-content">
        <div className="info-box">
          <h3>Integrering med befintlig wizard</h3>
          <p>Denna modul innehåller den fullständiga IM/Prospekt-generatorn som vi byggde tidigare.</p>
          <p>I en fullständig implementation skulle den befintliga wizarden renderas här, med tillgång till:</p>
          <ul>
            <li>Dokumenttypsväljare (IM vs. Prospekt)</li>
            <li>7-stegs wizard för datainmatning</li>
            <li>AI-generering av alla sektioner</li>
            <li>PDF-export</li>
          </ul>
          
          {project && (
            <div style={{marginTop: '2rem'}}>
              <strong>Aktivt projekt:</strong> {project.name}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default ProspektGenerator;
