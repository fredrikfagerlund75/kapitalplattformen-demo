const express = require('express');
const Anthropic = require('@anthropic-ai/sdk');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// ═══════════════════════════════════════════════════════════════════════════
//  MARKETING AUTOMATION ENDPOINTS (Fas 1 MVP)
// ═══════════════════════════════════════════════════════════════════════════

// Generate landing page
app.post('/api/marketing/generate-landing-page', async (req, res) => {
  try {
    const { projectId, companyName, emissionType, emissionSize } = req.body;
    
    // In production, this would:
    // 1. Fetch project data from database
    // 2. Generate HTML from template with dynamic content
    // 3. Deploy to hosting (Vercel/Netlify)
    // 4. Return live URL
    
    // Demo response
    const url = `https://kapital.demo/${companyName.toLowerCase().replace(/\s+/g, '-')}-emission`;
    
    res.json({
      url,
      seoScore: Math.floor(Math.random() * 15) + 85, // Random 85-100
      status: 'published',
      landingPageHtml: `
<!DOCTYPE html>
<html lang="sv">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${companyName} - Emission ${new Date().getFullYear()}</title>
  <meta name="description" content="${companyName} genomför en ${emissionType} om ${emissionSize}. Läs mer och teckna aktier här.">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 0; padding: 0; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 3rem 2rem; text-align: center; }
    .content { max-width: 800px; margin: 2rem auto; padding: 0 2rem; }
    .cta-button { background: #667eea; color: white; padding: 1rem 2rem; border: none; border-radius: 8px; font-size: 1.1rem; cursor: pointer; }
  </style>
</head>
<body>
  <div class="header">
    <h1>${companyName}</h1>
    <p>Emission ${new Date().getFullYear()} - ${emissionSize}</p>
  </div>
  <div class="content">
    <h2>Om emissionen</h2>
    <p>Vi genomför en företrädesemission för att finansiera vår fortsatta tillväxt.</p>
    <button class="cta-button">Teckna aktier</button>
  </div>
</body>
</html>
      `
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Setup email campaign
app.post('/api/marketing/setup-email-campaign', async (req, res) => {
  try {
    const { projectId, companyName } = req.body;
    
    // In production, this would:
    // 1. Create email templates in Mailchimp/HubSpot
    // 2. Schedule drip sequence based on emission dates
    // 3. Setup tracking pixels
    // 4. Return campaign ID
    
    const prompt = `Du är expert på email-marketing för kapitalanskaffningar.

Skapa tre korta email-ämnesrader för en emission från ${companyName}:

1. Pre-launch email (3 dagar före): ska skapa anticipation
2. Opening email (dag 1): ska kommunicera att emissionen öppnat
3. Last call email (2 dagar kvar): ska skapa urgency

Svara med endast tre ämnesrader, en per rad.`;

    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 500,
      messages: [{ role: 'user', content: prompt }]
    });

    const subjectLines = message.content[0].text.split('\n').filter(line => line.trim());
    
    res.json({
      campaignId: `camp_${Date.now()}`,
      status: 'scheduled',
      emails: [
        {
          type: 'pre-launch',
          subject: subjectLines[0] || `${companyName} - Emission öppnar snart`,
          scheduledDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
          type: 'opening',
          subject: subjectLines[1] || `${companyName} - Emissionen är öppen!`,
          scheduledDate: new Date(Date.now() + 6 * 24 * 60 * 60 * 1000).toISOString()
        },
        {
          type: 'last-call',
          subject: subjectLines[2] || `${companyName} - Sista chansen att teckna`,
          scheduledDate: new Date(Date.now() + 12 * 24 * 60 * 60 * 1000).toISOString()
        }
      ]
    });
  } catch (error) {
    console.error('Email campaign setup error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Setup Google Ads campaign
app.post('/api/marketing/setup-google-ads', async (req, res) => {
  try {
    const { projectId, companyName, budget } = req.body;
    
    // In production, this would:
    // 1. Create Google Ads campaign via API
    // 2. Setup keyword targeting
    // 3. Create ad copy variations
    // 4. Setup conversion tracking
    // 5. Return campaign ID and preview URL
    
    const prompt = `Du är expert på Google Ads för finansiella tjänster.

För ${companyName} som genomför en emission:

Generera 5 relevanta keywords för Google Search Ads (både exakta och breda).
Svara med endast keywords, en per rad.`;

    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 300,
      messages: [{ role: 'user', content: prompt }]
    });

    const keywords = message.content[0].text.split('\n').filter(line => line.trim()).slice(0, 5);
    
    res.json({
      campaignId: `gads_${Date.now()}`,
      status: 'active',
      budget,
      keywords,
      estimatedReach: Math.floor((budget / 10) * 100), // Rough estimate: 10 SEK CPM
      dashboardUrl: 'https://ads.google.com/demo'
    });
  } catch (error) {
    console.error('Google Ads setup error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get campaign analytics (demo endpoint)
app.get('/api/marketing/analytics/:projectId', async (req, res) => {
  try {
    // Demo analytics data
    res.json({
      landingPage: {
        visits: Math.floor(Math.random() * 5000) + 10000,
        uniqueVisitors: Math.floor(Math.random() * 3000) + 7000,
        bounceRate: (Math.random() * 20 + 30).toFixed(1) + '%',
        avgTimeOnPage: Math.floor(Math.random() * 120 + 60) + 's'
      },
      emailCampaign: {
        sent: Math.floor(Math.random() * 1000) + 2000,
        opens: Math.floor(Math.random() * 500) + 800,
        clicks: Math.floor(Math.random() * 200) + 200
      },
      googleAds: {
        impressions: Math.floor(Math.random() * 20000) + 30000,
        clicks: Math.floor(Math.random() * 800) + 1000,
        conversions: Math.floor(Math.random() * 50) + 70,
        cpl: Math.floor(Math.random() * 200) + 200
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ═══════════════════════════════════════════════════════════════════════════
//  SERVER START
// ═══════════════════════════════════════════════════════════════════════════

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Backend running on port ${PORT}`);
  console.log('API Key configured:', !!process.env.ANTHROPIC_API_KEY);
  console.log('\n📍 Available endpoints:');
  console.log('  POST /api/marketing/generate-landing-page');
  console.log('  POST /api/marketing/setup-email-campaign');
  console.log('  POST /api/marketing/setup-google-ads');
  console.log('  GET  /api/marketing/analytics/:projectId');
});
